#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Description
-----------

Module containing the base Problem class for pySDC
"""

import logging
from typing import Any, Dict, Optional, Type, Callable

from pySDC.core.common import RegisterParams


class WorkCounter(object):
    """
    Utility class for counting iterations.

    Contains one attribute `niter` initialized to zero during
    instantiation, which can be incremented by calling object as
    a function, e.g

    >>> count = WorkCounter()  # => niter = 0
    >>> count()                # => niter = 1
    >>> count()                # => niter = 2
    """

    def __init__(self) -> None:
        """Start counting at zero."""
        self.niter: int = 0

    def __call__(self, *args: Any, **kwargs: Any) -> None:
        # *args and **kwargs are necessary for gmres
        self.niter += 1

    def decrement(self) -> None:
        """Decrease `niter` by one, e.g. to take back a count."""
        self.niter -= 1

    def __str__(self) -> str:
        return f'{self.niter}'


class Problem(RegisterParams):
    r"""
    Prototype class for problems, just defines the attributes essential to get started.

    Parameters
    ----------
    init : list of args
        Argument(s) used to initialize data types.

    Attributes
    ----------
    logger: logging.Logger
        custom logger for problem-related logging.
    dtype_u : type
        Variable data type. Should generate a data variable using dtype_u(init).
    dtype_f : type
        RHS data type. Should generate a data variable using dtype_f(init).

    Notes
    -----
    **The correction-solve contract.** The deferred-correction ("delta-form") sweepers in
    :mod:`pySDC.implementations.sweeper_classes.delta_form` hand the implicit solve a *correction*
    equation instead of the state's. That is what lets the solver -- typically the expensive, often
    external part -- work in, and return, a much lower precision while the iteration still
    converges to full precision. Both sides of that call are specified here; nothing in it is
    required, and a problem that ignores it keeps working.

    The call is made per collocation node and sweep, by one of two routes:

    - linear or affine implicit operator: the stock :meth:`solve_system`, with the sweeper
      parameter ``linear_implicit=True``;
    - nonlinear implicit operator: ``solve_system_delta(rhs, factor, base, f_base, t)``, which
      solves :math:`\delta - factor\,[f(base+\delta) - f(base)] = rhs` and returns :math:`\delta`.
      This is the contract for an external nonlinear solver.

    Without either, the sweeper substitutes :math:`y = u^k_m + \delta_m` and calls
    :meth:`solve_system`. That is exact, but the solver then sees an :math:`\mathcal{O}(1)`
    unknown, and none of what follows holds.

    *The sweeper guarantees the solver*

    1. the unknown is a correction, the right-hand side is that of the correction equation, and it
       shrinks with the iteration like the residual; the initial guess is zero;
    2. on the linear route, a right-hand side of unit size: it is divided by its maximum before
       the call and the result multiplied by it after, which is exact and keeps any format clear of
       underflow. On the nonlinear route the scaled unknown would enter :math:`f`, so there the
       solver scales internally if its format needs it;
    3. ``base`` and ``f_base`` at the level's own precision, read only, and ``factor`` a plain
       scalar;
    4. that everything outside the solve -- the residual, the update :math:`u \leftarrow u +
       \delta`, and the increment :math:`f(u+\delta) - f(u)` -- stays at the level's precision, so
       every sweep is a step of iterative refinement around the solve.

    *The solver guarantees the sweeper*

    1. it returns the correction, not the state, in any precision: the sweeper widens it to the
       level's before using it;
    2. a relative accuracy :math:`\eta`, :math:`\|\tilde\delta - \delta\| \le \eta\|\delta\|`, below
       what the method needs. How it gets there -- its internal precision, iterative refinement, a
       Krylov tolerance, multigrid cycles -- is its own business;
    3. relative tolerances only, and none below what its own precision can deliver: an absolute
       tolerance caps the attainable accuracy, and an unreachable one costs iterations or, in a
       Krylov method, breaks it down;
    4. no boundary data or affine terms re-imposed on the correction, whose boundary conditions are
       homogeneous.

    Then the iteration converges to the level's precision, at an iteration cost set by
    :math:`\eta` alone. Measured on the heat equation: SDC needs :math:`\eta` of about 1e-4, an
    MLSDC fine level about 1e-6 and an MLSDC coarse level about 1e-2 to lose at most one iteration.

    One more optional method serves the contract. ``eval_f_increment(base, delta, t)`` returns
    :math:`f(base+\delta) - f(base)` with the same splitting as :meth:`eval_f`, expanded so that
    every term carries an explicit factor :math:`\delta`. Without it the sweeper subtracts two
    stored right-hand sides, a cancellation that carries the operator norm: on the FEniCS heat
    equation, where :math:`|M^{-1}Ku|` is of order :math:`10^5`, it is already 7.7e-11 off in
    double precision, and below double precision it binds before the solver does.
    """

    logger: logging.Logger = logging.getLogger('problem')
    dtype_u: Optional[Type[Any]] = None
    dtype_f: Optional[Type[Any]] = None

    def __init__(self, init: Any) -> None:
        """Store `init`, see the class docstring, and start without work counters."""
        self.work_counters: Dict[str, WorkCounter] = {}  # Dictionary to store WorkCounter objects
        self.init: Any = init  # Initialization parameter to instantiate data types

    @property
    def u_init(self) -> Any:
        """Generate a data variable for u"""
        return self.dtype_u(self.init)

    @property
    def f_init(self) -> Any:
        """Generate a data variable for RHS"""
        return self.dtype_f(self.init)

    @classmethod
    def get_default_sweeper_class(cls) -> Type[Any]:
        """
        Get the sweeper class to use with this problem if none is given, e.g. in `pySDC.helpers.setup_helper`.

        Returns
        -------
        type
            Sweeper class.

        Raises
        ------
        NotImplementedError
            If the problem class does not define a default.
        """
        raise NotImplementedError(f'No default sweeper class implemented for {cls} problem!')

    def setUpFieldsIO(self) -> None:
        """
        Set up FieldsIO for MPI with the space decomposition of this problem
        """
        pass

    def getOutputFile(self, fileName: str) -> Any:
        """
        Create the file the `LogToFile` hook writes the solution to. Implemented by problems that support file output.

        Parameters
        ----------
        fileName : str
            Name of the file.

        Returns
        -------
        pySDC.helpers.fieldsIO.FieldsIO
            File object with the header set and initialized.
        """
        raise NotImplementedError(f'No output implemented file for {type(self).__name__}')

    def processSolutionForOutput(self, u: Any) -> Any:
        """
        Convert a solution to the data written to the file from `getOutputFile`.

        Parameters
        ----------
        u : dtype_u
            Solution.

        Returns
        -------
        np.ndarray
            Data to write, `u` itself by default.
        """
        return u

    def eval_f(self, u: Any, t: float) -> Any:
        """
        Abstract interface to RHS computation of the ODE

        Parameters
        ----------
        u : dtype_u
            Current values.
        t : float
            Current time.

        Returns
        -------
        f : dtype_f
            The RHS values.
        """
        raise NotImplementedError('ERROR: problem has to implement eval_f(self, u, t)')

    def apply_mass_matrix(self, u: Any) -> Any:
        r"""
        Apply the problem's mass matrix, :math:`M \vec{u}`.

        There is deliberately no default implementation. The mass-matrix sweepers and transfers
        (``generic_implicit_mass``, ``imex_1st_order_mass``, ``base_transfer_mass``) build ``u0``,
        the FAS ``tau`` and the residual out of this, so a problem that does not implement it would
        silently compute the wrong thing instead of failing. The identity default that used to sit
        here did exactly that: it produced ``nan`` several sweeps later, with nothing pointing back
        to the missing method.
        """
        raise NotImplementedError(
            f'{type(self).__name__} is being used in a mass-matrix formulation but does not '
            'implement apply_mass_matrix'
        )

    def generate_scipy_reference_solution(
        self, eval_rhs: Callable, t: float, u_init: Optional[Any] = None, t_init: Optional[float] = None, **kwargs: Any
    ) -> Any:
        """
        Compute a reference solution using `scipy.solve_ivp` with very small tolerances.
        Keep in mind that scipy needs the solution to be a one dimensional array. If you are solving something higher
        dimensional, you need to make sure the function `eval_rhs` takes a flattened one-dimensional version as an input
        and output, but reshapes to whatever the problem needs for evaluation.

        The keyword arguments will be passed to `scipy.solve_ivp`. You should consider passing `method='BDF'` for stiff
        problems and to accelerate that you can pass a function that evaluates the Jacobian with arguments `jac(t, u)`
        as `jac=jac`.

        Args:
            eval_rhs (function): Function evaluate the full right hand side. Must have signature `eval_rhs(float: t, numpy.1darray: u)`
            t (float): current time
            u_init (pySDC.implementations.problem_classes.Lorenz.dtype_u): initial conditions for getting the exact solution
            t_init (float): the starting time

        Returns:
            numpy.ndarray: Reference solution
        """
        import numpy as np
        from scipy.integrate import solve_ivp

        kwargs = {
            'atol': 100 * np.finfo(float).eps,
            'rtol': 100 * np.finfo(float).eps,
            **kwargs,
        }
        u_init = self.u_exact(t=0) if u_init is None else u_init * 1.0
        t_init = 0 if t_init is None else t_init

        u_shape = u_init.shape
        return solve_ivp(eval_rhs, (t_init, t), u_init.flatten(), **kwargs).y[:, -1].reshape(u_shape)

    def get_fig(self) -> Any:
        """
        Get a figure suitable to plot the solution of this problem

        Returns
        -------
        self.fig : matplotlib.pyplot.figure.Figure
        """
        raise NotImplementedError

    def plot(self, u: Any, t: Optional[float] = None, fig: Optional[Any] = None) -> None:
        r"""
        Plot the solution. Please supply a figure with the same structure as returned by ``self.get_fig``.

        Parameters
        ----------
        u : dtype_u
            Solution to be plotted
        t : float
            Time to display at the top of the figure
        fig : matplotlib.pyplot.figure.Figure
            Figure with the correct structure

        Returns
        -------
        None
        """
        raise NotImplementedError

    def solve_system(self, rhs: Any, dt: float, u0: Any, t: float) -> Any:
        """
        Perform an Euler step.

        Args:
            rhs: Right hand side for the Euler step
            dt (float): Step size for the Euler step
            u0: Initial guess
            t (float): Current time

        Returns:
            solution to the Euler step
        """
        raise NotImplementedError

    def solve_jacobian(
        self, rhs: Any, dt: float, u: Optional[Any] = None, u0: Optional[Any] = None, t: float = 0, **kwargs: Any
    ) -> Any:
        """
        Solve the Jacobian for an Euler step, linearized around u.
        This defaults to an Euler step to accommodate linear problems.

        Args:
            rhs: Right hand side for the Euler step
            dt (float): Step size for the Euler step
            u: Solution to linearize around
            u0: Initial guess
            t (float): Current time

        Returns:
            Solution
        """
        return self.solve_system(rhs, dt, u0=u, t=t, **kwargs)
