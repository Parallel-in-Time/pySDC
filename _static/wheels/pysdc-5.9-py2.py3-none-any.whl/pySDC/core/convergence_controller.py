import logging
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING
from pySDC.helpers.pysdc_helper import FrozenClass

if TYPE_CHECKING:
    from pySDC.core.controller import Controller
    from pySDC.core.step import Step


# short helper class to add params as attributes
class Pars(FrozenClass):
    """
    Frozen parameters of a convergence controller as attributes, with defaults for `control_order` and `useMPI`.
    """

    def __init__(self, params: Dict[str, Any]) -> None:
        """
        Args:
            params (dict): Parameters to store as attributes, overriding the defaults
        """
        self.control_order: int = 0  # integer that determines the order in which the convergence controllers are called
        self.useMPI: Optional[bool] = None  # depends on the controller

        for k, v in params.items():
            setattr(self, k, v)

        self._freeze()


# short helper class to store status variables
class Status(FrozenClass):
    """
    Frozen container for named variables of a convergence controller.
    Initialize status variables with None, since at the time of instantiation of the convergence controllers, not all
    relevant information about the controller are known.
    """

    def __init__(self, status_variabes: List[str]) -> None:
        """
        Args:
            status_variabes (list of str): Names of the status variables, all initialized to None
        """
        [setattr(self, key, None) for key in status_variabes]

        self._freeze()


class ConvergenceController(object):
    """
    Abstract base class for convergence controllers, which plug into the controller to steer iterations and step sizes.
    """

    def __init__(
        self, controller: 'Controller', params: Dict[str, Any], description: Dict[str, Any], **kwargs: Any
    ) -> None:
        """
        Initialization routine

        Args:
            controller (pySDC.Controller): The controller
            params (dict): The params passed for this specific convergence controller
            description (dict): The description object used to instantiate the controller
        """
        self.controller: 'Controller' = controller
        self.params: Pars = Pars(self.setup(controller, params, description))
        params_ok, msg = self.check_parameters(controller, params, description)
        assert params_ok, f'{type(self).__name__} -- {msg}'
        self.dependencies(controller, description)
        self.logger: logging.Logger = logging.getLogger(f"{type(self).__name__}")

        if self.params.useMPI:
            self.prepare_MPI_datatypes()

    def prepare_MPI_logical_operations(self) -> None:
        """
        Prepare MPI logical operations so we don't need to import mpi4py all the time
        """
        from mpi4py import MPI

        self.MPI_LAND = MPI.LAND
        self.MPI_LOR = MPI.LOR

    def prepare_MPI_datatypes(self) -> None:
        """
        Prepare MPI datatypes so we don't need to import mpi4py all the time
        """
        from mpi4py import MPI

        self.MPI_INT = MPI.INT
        self.MPI_DOUBLE = MPI.DOUBLE
        self.MPI_BOOL = MPI.BOOL

    def log(self, msg: str, S: 'Step', level: int = 15, **kwargs: Any) -> None:
        """
        Shortcut that has a default level for the logger. 15 is above debug but below info.

        Args:
            msg (str): Message you want to log
            S (pySDC.step): The current step
            level (int): the level passed to the logger

        Returns:
            None
        """
        self.logger.log(level, f'Process {S.status.slot:2d} on time {S.time:.6f} - {msg}')
        return None

    def debug(self, msg: str, S: 'Step', **kwargs: Any) -> None:
        """
        Shortcut to pass messages at debug level to the logger.

        Args:
            msg (str): Message you want to log
            S (pySDC.step): The current step

        Returns:
            None
        """
        self.log(msg=msg, S=S, level=10, **kwargs)
        return None

    def setup(
        self, controller: 'Controller', params: Dict[str, Any], description: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Setup various variables that only need to be set once in the beginning.
        If the convergence controller is added automatically, you can give it params by adding it manually.
        It will be instantiated only once with the manually supplied parameters overriding automatically added
        parameters.

        This function scans the convergence controllers supplied to the description object for instances of itself.
        This corresponds to the convergence controller being added manually by the user. If something is found, this
        function will then return a composite dictionary from the `params` passed to this function as well as the
        `params` passed manually, with priority to manually added parameters. If you added the convergence controller
        manually, that is of course the same and nothing happens. If, on the other hand, the convergence controller was
        added automatically, the `params` passed here will come from whatever added it and you can now override
        parameters by adding the convergence controller manually.
        This relies on children classes to return a composite dictionary from their defaults and from the result of this
        function, so you should write

        .. code-block:: python

            return {**defaults, **super().setup(controller, params, description, **kwargs)}

        when overloading this method in a child class, with `defaults` a dictionary containing default parameters.

        Args:
            controller (pySDC.Controller): The controller
            params (dict): The params passed for this specific convergence controller
            description (dict): The description object used to instantiate the controller

        Returns:
            (dict): The updated params dictionary after setup
        """
        # allow to change parameters by adding the convergence controller manually
        return {**params, **description.get('convergence_controllers', {}).get(type(self), {})}

    def dependencies(self, controller: 'Controller', description: Dict[str, Any], **kwargs: Any) -> None:
        """
        Load dependencies on other convergence controllers here.

        Args:
            controller (pySDC.Controller): The controller
            description (dict): The description object used to instantiate the controller

        Returns:
            None
        """
        pass

    def check_parameters(
        self, controller: 'Controller', params: Dict[str, Any], description: Dict[str, Any], **kwargs: Any
    ) -> Tuple[bool, str]:
        """
        Check whether parameters are compatible with whatever assumptions went into the step size functions etc.

        Args:
            controller (pySDC.Controller): The controller
            params (dict): The params passed for this specific convergence controller
            description (dict): The description object used to instantiate the controller

        Returns:
            bool: Whether the parameters are compatible
            str: The error message
        """
        return True, ""

    def check_iteration_status(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Determine whether to keep iterating or not in this function.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def get_new_step_size(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        This function allows to set a step size with arbitrary criteria.
        Make sure to give an order to the convergence controller by setting the `control_order` variable in the params.
        This variable is an integer and you can see what the current order is by using
        `controller.print_convergence_controllers()`.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def determine_restart(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Determine for each step separately if it wants to be restarted for whatever reason.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def reset_status_variables(self, controller: 'Controller', **kwargs: Any) -> None:
        """
        Reset status variables.
        This is called in the `restart_block` function.
        Args:
            controller (pySDC.Controller): The controller

        Returns:
            None
        """
        return None

    def setup_status_variables(self, controller: 'Controller', **kwargs: Any) -> None:
        """
        Setup status variables.
        This is not done at the time of instantiation, since the controller is not fully instantiated at that time and
        hence not all information are available. Instead, this function is called after the controller has been fully
        instantiated.

        Args:
            controller (pySDC.Controller): The controller

        Returns:
            None
        """
        return None

    def reset_buffers_nonMPI(self, controller: 'Controller', **kwargs: Any) -> None:
        """
        Buffers refer to variables used across multiple steps that are stored in the convergence controller classes to
        imitate communication in non MPI versions. These have to be reset in order to replicate availability of
        variables in MPI versions.

        For instance, if step 0 sets self.buffers.x = 1 from self.buffers.x = 0, when the same MPI rank uses the
        variable with step 1, it will still carry the value of self.buffers.x = 1, equivalent to a send from the rank
        computing step 0 to the rank computing step 1.

        However, you can only receive what somebody sent and in order to make sure that is true for the non MPI
        versions, we reset after each iteration so you cannot use this function to communicate backwards from the last
        step to the first one for instance.

        This function is called both at the end of instantiating the controller, as well as after each iteration.

        Args:
            controller (pySDC.Controller): The controller

        Returns:
            None
        """
        pass

    def pre_iteration_processing(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Do whatever you want to before each iteration here.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def post_iteration_processing(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Do whatever you want to after each iteration here.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def post_iteration_processing_block(self, controller: 'Controller', **kwargs: Any) -> None:
        """
        Do whatever you want to after each iteration, once for the whole block rather than once per step.

        Use this instead of `post_iteration_processing` for state that belongs to the block rather than
        to a step. A convergence controller is instantiated once per *controller*, so anything stored on
        `self` spans a whole block in `controller_nonMPI` but a single rank under MPI, while the per-step
        hooks fire once per step. A recursion driven from a per-step hook therefore advances a different
        number of times depending only on how the run was decomposed. State that genuinely belongs to a
        step should go on `S.status` via `add_status_variable_to_step` instead.

        Note this fires once per iteration **per rank**, not once per block: under MPI every rank calls
        it, so a quantity that has to agree across the block still needs a reduction in here. See
        `AdaptiveAlpha` for how that looks.

        Note also what that does *not* buy you. Under a pipelined method an early step converges and
        drops out, so ranks take part in different numbers of iterations by design; a recursion driven
        from here therefore still advances a different number of times on different ranks, and that is
        the pipelining rather than a defect. Where every step iterates together -- ParaDiag, which
        cannot converge one step at a time because the transform needs them all -- this is exact.

        Args:
            controller (pySDC.Controller): The controller

        Returns:
            None
        """
        pass

    def post_step_processing(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Do whatever you want to after each step here.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def post_run_processing(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Do whatever you want to after the run here.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def prepare_next_block(
        self, controller: 'Controller', S: 'Step', size: int, time: Any, Tend: float, **kwargs: Any
    ) -> None:
        """
        Prepare stuff like spreading step sizes or whatever.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step
            size (int): The number of ranks
            time (float): The current time will be list in nonMPI controller implementation
            Tend (float): The final time

        Returns:
            None
        """
        pass

    def convergence_control(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Call all the functions related to convergence control.
        This is called in `it_check` in the controller after every iteration just after `post_iteration_processing`.
        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """

        self.get_new_step_size(controller, S, **kwargs)
        self.determine_restart(controller, S, **kwargs)
        self.check_iteration_status(controller, S, **kwargs)

        return None

    def communicate_convergence(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        Share convergence status across the block, however the block happens to be spread out.

        Called once per step after every step has decided for itself, which is the only point at
        which a reduction over the block is meaningful. `CheckConvergence` is the one that does
        something here.

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step

        Returns:
            None
        """
        pass

    def post_spread_processing(self, controller: 'Controller', S: 'Step', **kwargs: Any) -> None:
        """
        This function is called at the end of the `SPREAD` stage in the controller

        Args:
            controller (pySDC.Controller): The controller
            S (pySDC.Step): The current step
        """
        pass

    def send(self, comm, dest, data, blocking=False, **kwargs):
        """
        Send data to a different rank

        Args:
            comm (mpi4py.MPI.Intracomm): Communicator
            dest (int): The target rank
            data: Data to be sent
            blocking (bool): Whether the communication is blocking or not

        Returns:
            request handle of the communication
        """
        kwargs['tag'] = kwargs.get('tag', abs(self.params.control_order))

        # log what's happening for debug purposes
        self.logger.debug(f'Step {comm.rank} {"" if blocking else "i"}sends to step {dest} with tag {kwargs["tag"]}')

        if blocking:
            req = comm.send(data, dest=dest, **kwargs)
        else:
            req = comm.isend(data, dest=dest, **kwargs)

        return req

    def recv(self, comm, source, **kwargs):
        """
        Receive some data

        Args:
            comm (mpi4py.MPI.Intracomm): Communicator
            source (int): Where to look for receiving

        Returns:
            whatever has been received
        """
        kwargs['tag'] = kwargs.get('tag', abs(self.params.control_order))

        # log what's happening for debug purposes
        self.logger.debug(f'Step {comm.rank} receives from step {source} with tag {kwargs["tag"]}')

        data = comm.recv(source=source, **kwargs)

        return data

    def Send(self, comm, dest, buffer, blocking=False, **kwargs):
        """
        Send data to a different rank

        Args:
            comm (mpi4py.MPI.Intracomm): Communicator
            dest (int): The target rank
            buffer: Buffer for the data
            blocking (bool): Whether the communication is blocking or not

        Returns:
            request handle of the communication
        """
        kwargs['tag'] = kwargs.get('tag', abs(self.params.control_order))

        # log what's happening for debug purposes
        self.logger.debug(f'Step {comm.rank} {"" if blocking else "i"}Sends to step {dest} with tag {kwargs["tag"]}')

        if blocking:
            req = comm.Send(buffer, dest=dest, **kwargs)
        else:
            req = comm.Isend(buffer, dest=dest, **kwargs)

        return req

    def Recv(self, comm, source, buffer, **kwargs):
        """
        Receive some data

        Args:
            comm (mpi4py.MPI.Intracomm): Communicator
            source (int): Where to look for receiving
            buffer: Buffer to receive the data into

        Returns:
            None, the data is received into `buffer`
        """
        kwargs['tag'] = kwargs.get('tag', abs(self.params.control_order))

        # log what's happening for debug purposes
        self.logger.debug(f'Step {comm.rank} Receives from step {source} with tag {kwargs["tag"]}')

        data = comm.Recv(buffer, source=source, **kwargs)

        return data

    def add_status_variable_to_step(self, key, value=None):
        """
        Add a status variable to the steps of the controller and optionally set its value on all of them.

        The variable is registered on the class of the step status, see `FrozenClass.add_attr`, so it exists on every
        step.

        Args:
            key (str): Name of the status variable
            value: Value to set on all steps, which is skipped if None

        Returns:
            None
        """
        steps = self.controller.steps

        steps[0].status.add_attr(key)

        if value is not None:
            self.set_step_status_variable(key, value)

    def set_step_status_variable(self, key, value):
        """
        Set a status variable on all steps of the controller.

        Args:
            key (str): Name of the status variable, which must have been added already
            value: Value to set

        Returns:
            None
        """
        steps = self.controller.steps

        for S in steps:
            S.status.__dict__[key] = value

    def add_status_variable_to_level(self, key, value=None):
        """
        Add a status variable to the levels of the controller and optionally set its value on all of them.

        The variable is registered on the class of the level status, see `FrozenClass.add_attr`, so it exists on every
        level.

        Args:
            key (str): Name of the status variable
            value: Value to set on all levels of all steps, which is skipped if None

        Returns:
            None
        """
        steps = self.controller.steps

        steps[0].levels[0].status.add_attr(key)

        if value is not None:
            self.set_level_status_variable(key, value)

    def set_level_status_variable(self, key, value):
        """
        Set a status variable on all levels of all steps of the controller.

        Args:
            key (str): Name of the status variable, which must have been added already
            value: Value to set

        Returns:
            None
        """
        steps = self.controller.steps

        for S in steps:
            for L in S.levels:
                L.status.__dict__[key] = value
