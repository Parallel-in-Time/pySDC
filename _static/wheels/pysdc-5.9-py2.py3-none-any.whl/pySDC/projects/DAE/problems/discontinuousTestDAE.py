import numpy as np

from pySDC.core.problem import WorkCounter
from pySDC.projects.DAE.misc.problemDAE import ProblemDAE


class DiscontinuousTestDAE(ProblemDAE):
    r"""
    This class implements a scalar test discontinuous differential-algebraic equation (DAE) similar to [1]_. The event function
    is defined as :math:`h(y):= 2y - 100`. Then, the discontinuous DAE model reads:

    - if :math:`h(y) \leq 0`:

        .. math::
            \dfrac{d y(t)}{dt} = z(t),

        .. math::
            y(t)^2 - z(t)^2 - 1 = 0,

    else:

        .. math::
            \dfrac{d y(t)}{dt} = 0,

        .. math::
            y(t)^2 - z(t)^2 - 1 = 0,

    for :math:`t \geq 1`. If :math:`h(y) < 0`, the solution is given by

    .. math::
        (y(t), z(t)) = (cosh(t), sinh(t)),

    and the event takes place at :math:`t^* = arccosh(50) = 4.60507` and event point :math:`(cosh(t^*), sinh(t^*))`.
    As soon as :math:`t \geq t^*`, i.e., for :math:`h(y) \geq 0`, the solution is given by the constant value
    :math:`(cosh(t^*), sinh(t^*))`.

    After the event, :math:`h` stays at zero instead of changing its sign. A switch estimator, which looks for a sign
    change, then only sees the overshoot of the iterates. So with ``switch_on_state=False``, the dynamics switch only
    at the event time :math:`t_{switch}` the estimator has located, and :math:`h` changes its sign across the event.

    Parameters
    ----------
    nvars : int
        Number of unknowns of the system of DAEs.
    newton_tol : float
        Tolerance for Newton solver.
    switch_on_state : bool, optional
        Whether the dynamics switch where :math:`h(y) \geq 0`, or only after the located event time
        :math:`t_{switch}`. Set it to False when the event is located by a switch estimator.

    Attributes
    ----------
    t_switch_exact: float
        Exact time of the event :math:`t^*`.
    t_switch: float
        Time point of the event found by switch estimation.
    nswitches: int
        Number of switches found by switch estimation.

    References
    ----------
    .. [1] L. Lopez, S. Maset. Numerical event location techniques in discontinuous differential algebraic equations.
        Appl. Numer. Math. 178, 98-122 (2022).
    """

    def __init__(self, newton_tol=1e-12, switch_on_state=True):
        """Initialization routine"""
        super().__init__(nvars=2, newton_tol=newton_tol)
        self._makeAttributeAndRegister('switch_on_state', localVars=locals(), readOnly=True)

        self.t_switch_exact = np.arccosh(50)
        self.t_switch = None
        self.nswitches = 0
        self.work_counters['rhs'] = WorkCounter()

    def eval_f(self, u, du, t):
        r"""
        Routine to evaluate the implicit representation of the problem, i.e., :math:`F(u, u', t)`.

        Parameters
        ----------
        u : dtype_u
            Current values of the numerical solution at time t.
        du : dtype_u
            Current values of the derivative of the numerical solution at time t.
        t : float
            Current time of the numerical solution.

        Returns
        -------
        f : dtype_f
            The right-hand side of f (contains two components).
        """

        y, z = u.diff[0], u.alg[0]
        dy = du.diff[0]

        t_switch = np.inf if self.t_switch is None else self.t_switch

        h = 2 * y - 100
        f = self.dtype_f(self.init)

        if (self.switch_on_state and h >= 0) or t >= t_switch:
            f.diff[0] = dy
            f.alg[0] = y**2 - z**2 - 1
        else:
            f.diff[0] = dy - z
            f.alg[0] = y**2 - z**2 - 1
        self.work_counters['rhs']()
        return f

    def u_exact(self, t, **kwargs):
        r"""
        Routine for the exact solution at time :math:`t \leq 1`. For this problem, the exact
        solution is piecewise.

        Parameters
        ----------
        t : float
            Time of the exact solution.

        Returns
        -------
        me : dtype_u
            Exact solution.
        """

        assert t >= 1, 'ERROR: u_exact only available for t>=1'

        me = self.dtype_u(self.init)
        if t <= self.t_switch_exact:
            me.diff[0] = np.cosh(t)
            me.alg[0] = np.sinh(t)
        else:
            me.diff[0] = np.cosh(self.t_switch_exact)
            me.alg[0] = np.sinh(self.t_switch_exact)
        return me

    def du_exact(self, t, **kwargs):
        r"""
        Routine for the derivative of the exact solution at time :math:`t \leq 1`.
        For this problem, the exact solution is piecewise.

        Parameters
        ----------
        t : float
            Time of the exact solution.

        Returns
        -------
        me : dtype_u
            Derivative of exact solution.
        """

        assert t >= 1, 'ERROR: u_exact only available for t>=1'

        me = self.dtype_u(self.init)
        if t <= self.t_switch_exact:
            me.diff[0] = np.sinh(t)
            me.alg[0] = np.cosh(t)
        else:
            me.diff[0] = np.sinh(self.t_switch_exact)
            me.alg[0] = np.cosh(self.t_switch_exact)
        return me

    def get_switching_info(self, u, t):
        r"""
        Provides information about the state function of the problem. A change in sign of the state function
        indicates an event. If a sign change is detected, a root can be found within the step according to the
        intermediate value theorem.

        The state function for this problem is given by

        .. math::
           h(y(t)) = 2 y(t) - 100.

        Parameters
        ----------
        u : dtype_u
            Current values of the numerical solution at time :math:`t`.
        t : float
            Current time of the numerical solution.

        Returns
        -------
        switch_detected : bool
            Indicates whether a discrete event is found or not.
        m_guess : int
            The index before the sign changes.
        state_function : list
            Defines the values of the state function at collocation nodes where it changes the sign.
        """

        switch_detected = False
        m_guess = -100

        for m in range(1, len(u)):
            h_prev_node = 2 * u[m - 1].diff[0] - 100
            h_curr_node = 2 * u[m].diff[0] - 100
            if h_prev_node < 0 and h_curr_node >= 0:
                switch_detected = True
                m_guess = m - 1
                break

        state_function = [2 * u[m].diff[0] - 100 for m in range(len(u))]
        return switch_detected, m_guess, state_function

    def count_switches(self):
        """
        Setter to update the number of switches if one is found.
        """
        self.nswitches += 1
