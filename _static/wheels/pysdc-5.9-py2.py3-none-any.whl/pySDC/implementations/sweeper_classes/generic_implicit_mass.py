from pySDC.core.errors import ParameterError
from pySDC.implementations.sweeper_classes.generic_implicit import generic_implicit


def integrate_load_vectors(sweeper, F):
    """
    Integrate right-hand side values over the collocation nodes, dt Q F, for the mass-matrix sweepers.

    Unlike the parent sweepers' ``integrate``, each sum starts from its first term instead of a zero ``dtype_u``: in
    the mass formulation the right-hand side is a load vector, which a backend may keep apart from solution data (the
    Firedrake data types do, and refuse to mix them).

    Args:
        sweeper: The mass-matrix sweeper
        F (list): Right-hand side values at the nodes 1, ..., M

    Returns:
        list: dt Q F at the nodes 1, ..., M
    """
    L = sweeper.level
    Q = sweeper.coll.Qmat
    me = []
    for m in range(1, sweeper.coll.num_nodes + 1):
        me.append(L.dt * Q[m, 1] * F[0])
        for j in range(2, sweeper.coll.num_nodes + 1):
            me[-1] += L.dt * Q[m, j] * F[j - 1]
    return me


class generic_implicit_mass(generic_implicit):
    """Fully implicit SDC sweeper for the mass-matrix formulation (no M^-1 anywhere)."""

    def integrate(self):
        """
        Integrate the right-hand side, see :func:`integrate_load_vectors`.

        Returns:
            list: dt Q f at the nodes 1, ..., M, load vectors like f
        """
        return integrate_load_vectors(self, self.level.f[1:])

    def update_nodes(self):
        """
        Fully implicit sweep for problems posed in mass-matrix form, M u' = f(u), where eval_f
        returns the load vector f and solve_system solves (M - factor J) u = rhs with rhs already
        in the dual space. u0 carries the mass matrix on the finest level only; coarse levels
        receive it already applied from the space-time transfer.

        Returns:
            None
        """

        L = self.level
        P = L.prob

        # only if the level has been touched before
        assert L.status.unlocked

        # get number of collocation nodes for easier access
        M = self.coll.num_nodes

        # gather all terms which are known already (e.g. from the previous iteration)
        # this corresponds to u0 + QF(u^k) - QdF(u^k) + tau

        # get QF(u^k)
        integral = self.integrate()

        # u0 is a solution on every level, the transfer restricts it by L2 projection
        u0 = P.apply_mass_matrix(L.u[0])

        for m in range(M):
            # get -QdF(u^k)_m
            for j in range(1, M + 1):
                integral[m] -= L.dt * self.QI[m + 1, j] * L.f[j]

            # add initial value
            integral[m] += u0
            # add tau if associated
            if L.tau[m] is not None:
                integral[m] += L.tau[m]

        # do the sweep
        for m in range(0, M):
            # build rhs, consisting of the known values from above and new values from previous nodes (at k+1)
            rhs = P.dtype_u(integral[m])
            for j in range(1, m + 1):
                rhs += L.dt * self.QI[m + 1, j] * L.f[j]

            # implicit solve with prefactor stemming from the diagonal of Qd
            L.u[m + 1] = P.solve_system(
                rhs, L.dt * self.QI[m + 1, m + 1], L.u[m + 1], L.time + L.dt * self.coll.nodes[m]
            )

            # update function values
            L.f[m + 1] = P.eval_f(L.u[m + 1], L.time + L.dt * self.coll.nodes[m])

        # indicate presence of new values at this level
        L.status.updated = True

        return None

    def compute_end_point(self):
        """
        Compute u at the right point of the interval

        The value uend computed here is a full evaluation of the Picard formulation unless do_full_update==False

        Returns:
            None
        """

        # get current level and problem description
        L = self.level
        P = L.prob

        # check if Mth node is equal to right point and do_coll_update is false, perform a simple copy
        if self.coll.right_is_node and not self.params.do_coll_update:
            # a copy is sufficient
            L.uend = P.dtype_u(L.u[-1])
        else:
            raise NotImplementedError('Mass matrix sweeper expect u_M = u_end')

        return None

    def compute_residual(self, stage=None):
        """
        Computation of the residual using the collocation matrix Q

        Args:
            stage (str): The current stage of the step the level belongs to
        """

        # get current level and problem description
        L = self.level
        P = L.prob

        # Check if we want to skip the residual computation to gain performance
        # Keep in mind that skipping any residual computation is likely to give incorrect outputs of the residual!
        if stage in self.params.skip_residual_computation:
            L.status.residual = 0.0 if L.status.residual is None else L.status.residual
            return None

        # check if there are new values (e.g. from a sweep)
        # assert L.status.updated

        # compute the residual for each node

        # build QF(u)
        res_norm = []
        res = self.integrate()
        for m in range(self.coll.num_nodes):

            res[m] += P.apply_mass_matrix(L.u[0] - L.u[m + 1])
            # add tau if associated
            if L.tau[m] is not None:
                res[m] += L.tau[m]

            # Due to different boundary conditions we might have to fix the residual
            if getattr(L.prob, 'fix_bc_for_residual', False):
                L.prob.fix_residual(res[m])
            # use abs function from data type here
            res_norm.append(abs(res[m]))

        # find maximal residual over the nodes
        if L.params.residual_type == 'full_abs':
            L.status.residual = max(res_norm)
        elif L.params.residual_type == 'last_abs':
            L.status.residual = res_norm[-1]
        elif L.params.residual_type == 'full_rel':
            L.status.residual = max(res_norm) / abs(L.u[0])
        elif L.params.residual_type == 'last_rel':
            L.status.residual = res_norm[-1] / abs(L.u[0])
        else:
            raise ParameterError(
                f'residual_type = {L.params.residual_type} not implemented, choose '
                f'full_abs, last_abs, full_rel or last_rel instead'
            )

        # indicate that the residual has seen the new values
        L.status.updated = False

        return None
