from pySDC.core.hooks import Hooks


class LogRestarts(Hooks):
    """
    Record restarts as `restart` at the beginning of the step.
    """

    def post_step(self, step, level_number):
        """
        Record here if the step was restarted.

        Args:
            step (pySDC.Step.step): Current step
            level_number (int): Current level
        """
        super().post_step(step, level_number)

        L = step.levels[level_number]

        self.add_to_stats(
            process=step.status.slot,
            process_sweeper=L.sweep.rank,
            time=L.time,
            level=L.level_index,
            iter=step.status.iter,
            sweep=L.status.sweep,
            type='restart',
            value=int(step.status.get('restart')),
        )
