import cupy as cp

try:
    from mpi4py import MPI
except ImportError:
    MPI = None

from pySDC.implementations.datatype_classes.mesh import MultiComponentMeshMixin

try:
    from pySDC.helpers.NCCL_communicator import NCCLComm
except ImportError:
    NCCLComm = None


class cupy_mesh(cp.ndarray):
    """
    CuPy-based datatype for serial or parallel meshes.
    """

    comm = None
    xp = cp

    def __new__(cls, init, val=0.0, **kwargs):
        """
        Instantiates new datatype. This ensures that even when manipulating data, the result is still a mesh.

        Args:
            init: either another mesh or a tuple containing the dimensions, the communicator and the dtype
            val: value to initialize

        Returns:
            obj of type mesh

        """
        if isinstance(init, cupy_mesh):
            obj = cp.ndarray.__new__(cls, shape=init.shape, dtype=init.dtype, **kwargs)
            obj[:] = init[:]
            # a fresh array of its own, so `__array_finalize__` has nothing to inherit from and the
            # communicator has to be carried over by hand
            obj.comm = init.comm
        elif (
            isinstance(init, tuple)
            and (init[1] is None or isinstance(init[1], MPI.Intracomm) or isinstance(init[1], NCCLComm))
            and isinstance(init[2], cp.dtype)
        ):
            obj = cp.ndarray.__new__(cls, init[0], dtype=init[2], **kwargs)
            obj.fill(val)
            obj.comm = init[1]
        else:
            raise NotImplementedError(type(init))
        return obj

    def __array_ufunc__(self, ufunc, method, *inputs, out=None, **kwargs):
        """
        Overriding default ufunc, cf. https://numpy.org/doc/stable/user/basics.subclassing.html#array-ufunc-for-ufuncs
        """
        args = []
        for _, input_ in enumerate(inputs):
            if isinstance(input_, cupy_mesh):
                args.append(input_.view(cp.ndarray))
            else:
                args.append(input_)
        results = super(cupy_mesh, self).__array_ufunc__(ufunc, method, *args, **kwargs).view(type(self))

        # the inputs were viewed as plain arrays just above, so the result has no communicator to
        # inherit through `__array_finalize__`; carry this one's over explicitly. A reduction or a
        # comparison can return a scalar rather than an array, and a scalar takes no attributes.
        if isinstance(results, cp.ndarray):
            results.comm = self.comm

        return results

    def __array_finalize__(self, obj):
        """
        Carry the communicator onto every array derived from this one.

        CuPy honours this hook, so a slice keeps the communicator. What reaches here from a ufunc
        or a copy is a plain `cupy.ndarray` with nothing to carry, which is why those propagate it
        themselves.
        """
        if obj is not None:
            self.comm = getattr(obj, 'comm', None)

    def __abs__(self):
        """
        Overloading the abs operator

        Returns:
            float: absolute maximum of all mesh values
        """
        # take absolute values of the mesh values
        local_absval = cp.max(cp.ndarray.__abs__(self))

        if self.comm is not None:
            if self.comm.Get_size() > 1:
                global_absval = local_absval * 0
                if isinstance(self.comm, NCCLComm):
                    self.comm.Allreduce(sendbuf=local_absval, recvbuf=global_absval, op=MPI.MAX)
                else:
                    global_absval = self.comm.allreduce(sendobj=float(local_absval), op=MPI.MAX)
            else:
                global_absval = local_absval
        else:
            global_absval = local_absval

        return float(global_absval)

    def copy(self, *args, **kwargs):
        """
        Copy the mesh, keeping its type.

        CuPy's ``ndarray`` is a Cython extension type whose ``copy`` returns the base class rather than
        ``type(self)``, unlike NumPy's. Without this, a copy of a mesh silently stops being one and loses the
        components along with the ``__abs__`` that does the MPI reduction.

        Returns:
            mesh: copy of the mesh, of the same type
        """
        copied = super().copy(*args, **kwargs).view(type(self))
        copied.comm = self.comm
        return copied

    def __deepcopy__(self, memo=None):
        """
        CuPy routes ``copy.deepcopy`` through ``copy``, so the type has to be kept here as well.
        """
        return self.copy()

    def isend(self, dest=None, tag=None, comm=None):
        """
        Routine for sending data forward in time (non-blocking)

        Args:
            dest (int): target rank
            tag (int): communication tag
            comm: communicator

        Returns:
            request handle
        """
        return comm.Issend(self[:], dest=dest, tag=tag)

    def irecv(self, source=None, tag=None, comm=None):
        """
        Routine for receiving in time

        Args:
            source (int): source rank
            tag (int): communication tag
            comm: communicator

        Returns:
            None
        """
        return comm.Irecv(self[:], source=source, tag=tag)

    def bcast(self, root=None, comm=None):
        """
        Routine for broadcasting values

        Args:
            root (int): process with value to broadcast
            comm: communicator

        Returns:
            broadcasted values
        """
        comm.Bcast(self[:], root=root)
        return self


class CuPyMultiComponentMesh(MultiComponentMeshMixin, cupy_mesh):
    """CuPy-based mesh with multiple components, see ``MultiComponentMeshMixin``."""


class imex_cupy_mesh(CuPyMultiComponentMesh):
    """CuPy mesh with an implicit part ``impl`` and an explicit part ``expl``, for IMEX right-hand sides."""

    components = ['impl', 'expl']


class comp2_cupy_mesh(CuPyMultiComponentMesh):
    """CuPy mesh with two parts ``comp1`` and ``comp2``, for multi-implicit right-hand sides."""

    components = ['comp1', 'comp2']
